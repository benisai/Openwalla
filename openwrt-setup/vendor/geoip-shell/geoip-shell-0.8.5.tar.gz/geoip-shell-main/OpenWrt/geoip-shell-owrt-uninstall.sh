#!/bin/sh
# shellcheck disable=SC2034,SC1090,SC2154

# geoip-shell-owrt-uninstall.sh

# trimmed down uninstaller specifically for the OpenWrt geoip-shell package

# Copyright: antonk (antonk.d3v@gmail.com)
# github.com/friendly-bits

p_name="geoip-shell"
GS_ID=owrt_uninstall
MANMODE=1
NOLOG=1
IN_UNINSTALL=1
export FORCE_SOURCE_LIBS=1

LIB_DIR="/usr/lib/$p_name"
_lib="$LIB_DIR/$p_name-lib"

geoinit="${p_name}-geoinit.sh"
geoinit_path="/usr/bin/$geoinit"
init_script="/etc/init.d/${p_name}-init"

[ -f "$geoinit_path" ] && . "$geoinit_path" ||
{
	[ -f "${_lib}-owrt.sh" ] && . "${_lib}-owrt.sh" &&
	[ -f "${_lib}-common.sh" ] && . "${_lib}-common.sh" ||
	{ logger -s -t "owrt-uninstall" -p user.err "Failed to source essential libraries."; exit 1; }
}

source_lib owrt

[ "$_fw_backend" ] ||
for _fw_backend in ipt nft; do
	checkutil check_fw_backend &&
		check_fw_backend -nolog "$_fw_backend" 1>/dev/null && break
	false
done || _fw_backend=''

[ "$_fw_backend" ] && source_lib "$_fw_backend" ||
	echolog -err "$FAIL load the firewall-specific library. Cannot remove firewall rules."

: "${CONF_DIR:="/etc/$p_name"}"
: "${GEORUN_DIR:="/tmp/$p_name-run"}"
[ -d "$CONF_DIR" ] && : "${CONF_FILE:="$CONF_DIR/$p_name.conf"}"

[ -s "$CONF_FILE" ] && nodie=1 load_config main "" "datadir local_iplists_dir"
: "${datadir:="${GEORUN_DIR}/data"}"
: "${local_iplists_dir:="/var/lib/$p_name/local_iplists"}"

rm_setupdone
[ -s "$init_script" ] && $init_script disable
rm_owrt_fw_include
kill_geo_pids
rm_lock
checkutil rm_iplists_rules && rm_iplists_rules
rm_cron_jobs
rm_data
rm -f "${INSTALL_DIR}/${p_name}"
if is_dir_empty "$local_iplists_dir"; then
	rm_geodir "$local_iplists_dir" "local IP lists"
	rm_dir_if_empty "$datadir"
else
	echolog "NOTE: local IP lists are not removed." \
		"If you are not planning to re-install $p_name, manually remove the directory '$local_iplists_dir'."
fi
