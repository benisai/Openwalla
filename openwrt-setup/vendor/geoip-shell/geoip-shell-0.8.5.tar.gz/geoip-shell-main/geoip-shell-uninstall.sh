#!/bin/sh
# shellcheck disable=SC2154,SC2086,SC2034,SC1090

# geoip-shell-uninstall

# Copyright: antonk (antonk.d3v@gmail.com)
# github.com/friendly-bits

# uninstalls or resets geoip-shell

#### Initial setup
p_name="geoip-shell"
GS_ID=uninstall
script_dir=$(CDPATH='' cd -- "$(dirname -- "$0")" && pwd -P)

MANMODE=1
NOLOG=1
IN_UNINSTALL=1
export FORCE_SOURCE_LIBS=1

case "$script_dir" in
	"/usr/bin"|'')
		geoinit_dir=/usr/bin
		lib_src_dir="$LIB_DIR" ;;
	*)
		geoinit_dir="$script_dir"
		lib_src_dir="$script_dir/lib"
esac

geoinit_path="${geoinit_dir}/${p_name}-geoinit.sh"
[ -f "$geoinit_path" ] && . "$geoinit_path" || { printf '%s\n' "Can not find '${geoinit_path}'." >&2; exit 1; }

san_args "$@"
newifs "$delim"
set -- $_args
oldifs

debugentermsg

#### USAGE

usage() {
cat <<EOF
Usage: $me [-r] [-V] [-d] [-h]

1) Removes geoip firewall rules
2) Removes geoip cron jobs
3) Deletes scripts' data folder (/var/lib/geoip-shell or /etc/geoip-shell/data on OpenWrt)
4) Deletes the scripts from /usr/sbin
5) Deletes the config folder /etc/geoip-shell

Options:
  -r  : Leave the config file and the backup files in place
  -V  : Version
  -d  : Debug
  -h  : This help

EOF
}

rm_scripts() {
	printed=
	for script_name in fetch apply manage cronsetup run backup mk-fw-include fw-include uninstall geoinit; do
		s_path="${INSTALL_DIR}/${p_name}-$script_name.sh"
		[ -f "$s_path" ] && {
			[ ! "$printed" ] && { printf '%s\n' "Deleting $p_name main scripts from $INSTALL_DIR..."; printed=1; }
			rm -f "$s_path"
		}
	done

	rm_geodir "$LIB_DIR" "library scripts"
	:
}


#### PARSE ARGUMENTS

while getopts ":rVdh" opt; do
	case $opt in
		r) keepdata="-r" ;;
		V) echo "$curr_ver"; die 0 ;;
		d) debugmode=1 ;;
		h) usage; die 0 ;;
		*) ;;
	esac
done
shift $((OPTIND-1))

is_root_ok || die

### VARIABLES
: "${INSTALL_DIR:="/usr/bin"}"
: "${CONF_DIR:="/etc/$p_name"}"
: "${GEORUN_DIR:="/tmp/$p_name-run"}"

old_install_dir="$(command -v "$p_name")"
old_install_dir="${old_install_dir%/*}"
INSTALL_DIR="${old_install_dir:-"$INSTALL_DIR"}"

[ ! "$INSTALL_DIR" ] && die "Can not determine installation directory. Try setting \$INSTALL_DIR manually."

[ "$script_dir" != "$INSTALL_DIR" ] && [ -f "$INSTALL_DIR/${p_name}-uninstall.sh" ] && [ ! "$norecur" ] && {
	# prevents infinite loop
	export norecur=1
	call_script "$INSTALL_DIR/${p_name}-uninstall.sh" "$keepdata" && die 0
}

[ -d "$CONF_DIR" ] && : "${CONF_FILE:="$CONF_DIR/$p_name.conf"}"
[ -s "$CONF_FILE" ] && nodie=1 load_config main "" "datadir firewall_backend=_fw_backend local_iplists_dir" ||
	{
		[ ! "$FIRST_SETUP" ] &&
			echolog -warn "Config file doesn't exist or failed to read config." \
				"Firewall rules may not be removed by the uninstaller. Please restart the machine after uninstallation."
	}

: "${datadir:="/var/lib/$p_name"}"
: "${local_iplists_dir:="/var/lib/$p_name/local_iplists"}"

#### MAIN

rm_setupdone

# kill any related processes which may be running in the background
kill_geo_pids

# remove the lock file
rm_lock

### Remove geoblocking rules

if [ -z "$_fw_backend" ] && [ -n "$old_install_dir" ] && detect_fw_backends; then
	case "$_FW_BACKEND_DEF" in
		'') ;;
		ipt|nft) _fw_backend="$_FW_BACKEND_DEF" ;;
		ask)
			# resort to heuristics
			if [ "$NFT_OK" ]; then
				_fw_backend=nft
			elif [ "$IPT_OK" ]; then
				_fw_backend=ipt
			fi
			# if not re-installing
			[ "$_fw_backend" ] && [ ! "$keepdata" ] &&
				echolog -warn "Based on heuristics, using firewall backend '${_fw_backend}ables' to remove existing geoblocking rules."
	esac
fi

LIB_SRC_DIR="$lib_src_dir" rm_iplists_rules
rm_cron_jobs

[ -n "$keepdata" ] && die 0

# For OpenWrt
[ "$_OWRT_install" ] && {
	rm_owrt_init
	rm_owrt_fw_include
	reload_owrt_fw
}

rm -f "${INSTALL_DIR}/${p_name}"
rm_scripts

rm_geodir "$CONF_DIR" config


rm_all_data

rm -rf "$GEOTEMP_DIR" "$GEORUN_DIR"

printf '%s\n\n' "Uninstall complete."

die 0